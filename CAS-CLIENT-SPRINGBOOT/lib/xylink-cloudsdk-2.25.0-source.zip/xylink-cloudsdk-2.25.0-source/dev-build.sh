#!/bin/sh

gradle clean publish -Pprofile=dev --stacktrace --refresh-dependencies
