说明：
1.src/main/java/ 目录下对应的是源码
2.test/java/com/xylink/sdk/test/ 目录下对应的是单个接口的单元测试示例
3.test/java/com/xylink/sdk/simple/ 目录下对应的是简单流程示例
4.enterprise_id和token 用户可换为自己对应的参数进行测试，也可不用替换直接测试看运行效果
5.跑测试的时候请注意注释说明，有些场景有依赖必须提前处理