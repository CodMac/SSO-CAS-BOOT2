#!/usr/bin/env bash
gradle clean publish -Pprofile=dev --stacktrace --refresh-dependencies