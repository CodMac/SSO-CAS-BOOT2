package com.xylink.sdk.test;


import com.xylink.config.SDKConfigMgr;
import com.xylink.model.*;
import com.xylink.model.statis.CurrentMeetingDetail;
import com.xylink.sdk.conferenceControl.ConferenceControlApi;
import com.xylink.sdk.conferenceControl.CreateMeetingApi;
import com.xylink.sdk.user.UserValidateApi;
import com.xylink.util.AES256Util;
import com.xylink.util.Result;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: gzm
 * Date: 2018-12-08
 */
public class UserTest {

    UserValidateResponse userValidateResponse = null;
    private String enterpriseid= TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();

    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://cloud.xylink.com");
    }

    @Test
    public void userValidate() {
        enterpriseid = "40260e9046bae2da238ac0b0c572326b91726a83";
        UserValidateApi userValidateApi = new UserValidateApi();
        ExternalLoginRequest externalLoginRequest = new ExternalLoginRequest();
        externalLoginRequest.setUserPhone("10098123862");
        externalLoginRequest.setPassword(AES256Util.AESEncode("UET3UM"));
        try {
            userValidateResponse = userValidateApi.userValidate(enterpriseid, token,
                    externalLoginRequest);
            if (userValidateResponse != null){
                System.out.println("responds:" + userValidateResponse.toString());
            }
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }

}
