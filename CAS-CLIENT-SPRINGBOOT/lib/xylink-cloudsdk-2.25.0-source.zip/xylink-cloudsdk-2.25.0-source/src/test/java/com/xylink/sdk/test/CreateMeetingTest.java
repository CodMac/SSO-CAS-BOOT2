package com.xylink.sdk.test;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.MeetingInfo;
import com.xylink.model.Pager;
import com.xylink.model.SdkCloudMeetingRoomRequest;
import com.xylink.model.SdkMeeting;
import com.xylink.model.SdkMeetingReq;
import com.xylink.sdk.conferenceControl.CreateMeetingApi;
import com.xylink.util.Result;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import javax.xml.transform.Source;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by changxiangyang on 2017/9/19.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CreateMeetingTest {

    private String roomNumber = "";
    private String enterpriseid= TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();

    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://sdk.xylink.com");
//        SDKConfigMgr.setServerHost("http://127.0.0.1:8081");
    }

    //创建会议 TODO 会议室号不能重复
    @Test
    public void createMeeting(){
        CreateMeetingApi cma=new CreateMeetingApi();
        SdkMeetingReq smr=new SdkMeetingReq();
        smr.setMeetingName("room1");
        smr.setStartTime(System.currentTimeMillis() + (1000 * 60 * 2));
        smr.setDuration(1000 * 6000);
        smr.setMaxParticipantCount(5);
        smr.setAutoRecord(false);
        try {
            SdkMeeting meeting = cma.createMeeting(enterpriseid, token, smr);
            System.out.println(meeting);
            roomNumber = meeting.getMeetingNumber();
            // 成功示例：SdkMeeting{meetingNumber='910056972431', controlPassword='125102', password='', shareUrl='http://sdk.xylink.com/page/third/KUUSKTJC'}
        }catch (Exception e){
            System.out.println("testgetMeetingStatus--"+e);
        }
    }

    //创建会议
    @Test
    public void createMeetingV2(){
        CreateMeetingApi cma=new CreateMeetingApi();
        SdkCloudMeetingRoomRequest sdkCloudMeetingRoomRequest=new SdkCloudMeetingRoomRequest();
        sdkCloudMeetingRoomRequest.setMeetingName("room1-dddd");
        sdkCloudMeetingRoomRequest.setStartTime(System.currentTimeMillis() + (1000 * 60 * 2));
        sdkCloudMeetingRoomRequest.setEndTime(System.currentTimeMillis() + (1000 * 60 * 3));
        sdkCloudMeetingRoomRequest.setMaxParticipant(4);
        sdkCloudMeetingRoomRequest.setAutoMute(0);
        Map<String, String> configs = new HashMap<String, String>();
        configs.put("autoRecord", "false");
        sdkCloudMeetingRoomRequest.setConfigs(configs);

        try {
            SdkMeeting meeting = cma.createMeetingV2(enterpriseid, token, sdkCloudMeetingRoomRequest);
            System.out.println(meeting);
            roomNumber = meeting.getMeetingNumber();
            // 成功示例：SdkMeeting{meetingNumber='910056972431', controlPassword='125102', password='', shareUrl='http://sdk.xylink.com/page/third/KUUSKTJC'}
        }catch (Exception e){
            System.out.println("testgetMeetingStatus--"+e);
        }
    }

    //按照会议号查询会议信息 TODO 云会议号保证有效
    @Test
    public void getMeetingInfo(){
        roomNumber = "910060717531";
        CreateMeetingApi cma=new CreateMeetingApi();

        Result<MeetingInfo> result=null;
        try {
            result=cma.getMeetingInfo(enterpriseid, token, roomNumber);
            System.out.println(result);
        }catch (IOException e){
            e.printStackTrace();
            fail(e.getMessage());
        }
        if(result.getErrorStatus()<300) {
            if (result != null) {
                MeetingInfo meetingInfo = result.getData();
                // TODO 这里的room1 是云会议室创建或修改后的云会议室名称
                assertEquals(meetingInfo.getMeettingRoomName(), "room1");
            }
        }else{
            fail(result.getErrorStatus() + "");
        }
    }
    //修改会议信息 TODO 云会议号保证有效
    @Test
    public void updateMeetingInfo(){
        roomNumber = "910056972431";
        CreateMeetingApi cma=new CreateMeetingApi();
        MeetingInfo meetingInfo=new MeetingInfo();
        meetingInfo.setAutoRecord(false);
        meetingInfo.setAutoMute(2);
//        meetingInfo.setMeettingRoomName("aaaa");
        try {
            Result result = cma.updateMeetingInfo(enterpriseid, token, roomNumber,meetingInfo);
            assertEquals(200, result.getErrorStatus());
        }catch (IOException e){
            fail(e.getMessage());
        }
        try {
            Result<MeetingInfo> result = cma.getMeetingInfo(enterpriseid, token, roomNumber);
            System.out.println("更新后查询到的云会议室：" + result);
            meetingInfo = result.getData();
            assertEquals(result.getData().getAutoMute(), 2);
            assertFalse(result.getData().isAutoRecord());
        } catch (IOException e) {
            fail(e.getMessage());
        }

        meetingInfo.setMeettingRoomName("aaa");
        meetingInfo.setAutoRecord(true);
        try {
            Result result = cma.updateMeetingInfo(enterpriseid, token, roomNumber,meetingInfo);
            assertEquals(200, result.getErrorStatus());
        }catch (IOException e){
            fail(e.getMessage());
        }

        try {
            Result<MeetingInfo> result = cma.getMeetingInfo(enterpriseid, token, roomNumber);
            assertEquals(result.getData().getMeettingRoomName(), "aaa");
            assertTrue(result.getData().isAutoRecord());
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }
    //批量查询会议信息 TODO 云会议号保证有效
    @Test
    public void getBatchMeetingInfo(){
        roomNumber = "910056972431";
        CreateMeetingApi cma=new CreateMeetingApi();
        String [] meetingRoomNos={roomNumber};
        try {
            Result<MeetingInfo[]> batchMeetingInfo = cma.getBatchMeetingInfo(enterpriseid, token, meetingRoomNos);
            System.out.println(batchMeetingInfo);
        }catch (IOException e){
            System.out.println("testGetBatchMeetingInfo--"+e);
        }
    }
    //删除会议 TODO 云会议号保证有效
    @Test
    public void xdeleteMeetingInfo(){
        roomNumber = "910056972431";
        CreateMeetingApi cma=new CreateMeetingApi();
        try {
            cma.deleteMeetingInfo(enterpriseid, token, roomNumber);
        }catch (IOException e){
            fail(e.getMessage());
        }
    }

    //查询某公司的sdk创建的会议
    @Test
    public void getSdkMeetingRooms(){
        CreateMeetingApi cma=new CreateMeetingApi();
        try {
            Result<MeetingInfo[]> sdkMeetingRooms = cma.getSdkMeetingRooms(enterpriseid, token);
            System.out.println(sdkMeetingRooms);
        }catch (IOException e){
            fail(e.getMessage());
        }
    }

    @Test
    public void getSdkMeetingRoomsByPage(){
        CreateMeetingApi cma=new CreateMeetingApi();
        String enterpriseid = "f3c422a7c36eac6c924ed2a50eb4f49f82b128de";
        String token = "a727338bb95fb608dde30774a96ae712c4a71ab3a4d6b499282048852bfe5a43";
        int page = 0;
        int size = 20;
        try {
            Result<Pager<MeetingInfo>> sdkMeetingRooms = cma.getSdkMeetingRooms(enterpriseid, token, page, size);
            System.out.println(sdkMeetingRooms);
        }catch (IOException e){
            fail(e.getMessage());
        }
    }
}
