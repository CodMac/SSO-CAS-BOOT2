package com.xylink.sdk.test;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.LV;
import com.xylink.model.LiveVideo;
import com.xylink.model.Status;
import com.xylink.sdk.liveVideo.v3.LiveVideoApi;
import com.xylink.util.Result;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by wangdecheng on 10/05/2018.
 */
public class LiveVideoV3Test {
    private String confNo = "";
    private String enterpriseid = TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();
    private String confPwd = "";

    @BeforeClass
    public static void setup() {
//        SDKConfigMgr.setServerHost("https://sdk.xylink.com");
        SDKConfigMgr.setServerHost("http://127.0.0.1:8081");
    }

    // TODO 云会议室号（confNo）必须有效
    @Test
    public void newLive(){
        confNo = "910056138646";
        LiveVideoApi lva=new LiveVideoApi();
        LiveVideo liveVideo=new LiveVideo();
        liveVideo.setTitle("我的直播");
        liveVideo.setStartTime(System.currentTimeMillis() + 1000 * 3600);
        liveVideo.setEndTime(System.currentTimeMillis() + 2 * 1000 * 3600);
        liveVideo.setAutoRecording(false);
        liveVideo.setAutoPublishRecording(false);
        liveVideo.setLocation("喜马拉雅山");
        Result result=null;
        try {
            result = lva.newLiveVideo(enterpriseid, token, confNo, liveVideo);
            System.out.println("预约直播结果：" + result);
            // 成功示例：预约直播结果：{"success":true,"errorStatus":200,"data":{"enterpriseId":"12e53a6df2e91e6177e627c8e336a6888ff98104","nemoNumber":"","confNo":"910056972431","title":"我的直播","startTime":1536743674891,"endTime":1536747274891,"detail":null,"autoRecording":false,"autoPublishRecording":false,"location":"喜马拉雅山","flv":"http://prdlive.ainemo.com/prdnemo/ff808081655d38460165ccd8a9b76fad.flv?auth_key=1536833674-0-0-c43b1c89943f2b51d3c4289d2cbb8ea6","hls":"http://prdlive.ainemo.com/prdnemo/ff808081655d38460165ccd8a9b76fad.m3u8?auth_key=1536833674-0-0-23f2bd7c27842edd76d5e6f8496e1608","liveId":"ff808081655d38460165ccd8a9b76fad","status":"WAIT","viewUrl":"http://sdk.xylink.com/live/v/ff808081655d38460165ccd8a9b76fad"}}
            if(result!=null){
                System.out.println(result.getErrorStatus());
                if(result.getErrorStatus()==200){
                    LV lv= (LV) result.getData();
                    System.out.println("lv="+lv.toString());
                    // 成功示例：lv=LV{liveId='ff808081655d38460165ccd8a9b76fad', status='WAIT', viewUrl='http://sdk.xylink.com/live/v/ff808081655d38460165ccd8a9b76fad'}
                }
            }
        }catch (IOException e){
            System.out.println("testEnd--"+e);
            throw  new RuntimeException(e);
        }
    }

    /**
     * 开始结束直播
     * TODO 开始直播前，保证已经呼起云会议号,当前示例呼起 910056972431
     */
    @Test
    public void goLive(){
        confNo = "910056138646";
        confPwd= "";
        Result result = null;
        LiveVideoApi lva=new LiveVideoApi();
        String liveId = "ff80808166674d2f016667a8296a0074";
        Status status = new Status();
        status.setStatus("start");
        try{
            result = lva.controlLive(enterpriseid, token, confNo, confPwd, liveId, status);
            System.out.println("result：" + result);
        }catch(Exception e){
            System.out.println(e);
        }
    }


}
