package com.xylink.sdk.test;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.PageableNemoDto;
import com.xylink.sdk.enterpriseNemo.EnterpriseNemoApi;
import com.xylink.util.Result;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by changxiangyang on 2017/11/1.
 */
public class BuffetNemoTest {
    private String enterpriseId= TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();

    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://sdk.xylink.com");
//        SDKConfigMgr.setServerHost("http://127.0.0.1:8081");
    }


    @Test
    public void get(){
        String enterpriseId = "12e53a6df2e91e6177e627c8e336a6888ff98104";
        String token = "a8208f6495ba1d468343cc63c13c5202837b5ba8614bdc699f46e91b4df09fd0";
        EnterpriseNemoApi enterpriseNemoApi=new EnterpriseNemoApi();
        try {
            Result<PageableNemoDto> nemos = enterpriseNemoApi.getPageableEnterpriseNemos(enterpriseId, token, 0, 10);
            System.out.println(nemos);
            int errStatus =nemos.getErrorStatus();
            if (errStatus<300) {
                System.out.println("getNemo测试成功！");
            }else {
                System.out.println("getNemo测试失败！");
            }
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }

}
