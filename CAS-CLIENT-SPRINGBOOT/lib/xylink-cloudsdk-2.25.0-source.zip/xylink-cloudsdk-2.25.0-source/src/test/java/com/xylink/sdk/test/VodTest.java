package com.xylink.sdk.test;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.ExternalLoginRequest;
import com.xylink.sdk.user.UserValidateApi;
import com.xylink.sdk.vod.VodApi;
import com.xylink.util.AES256Util;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.fail;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: gzm
 * Date: 2018-12-11
 */
public class VodTest {

    private String enterpriseid= TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();

    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://cloud.xylink.com");
    }

    @Test
    public void videoDownload() {
        enterpriseid = "ddb7d2bb194a8060affa776a8715b32b28171383";
        token = "9e1ea7c0c02913f2de760a194b43f9eb5a191e8d2789ab5403392d56870e5bcc";
        VodApi vodApi = new VodApi();
        try {
            vodApi.videoDownload(enterpriseid, token, "1693086");
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }
}
