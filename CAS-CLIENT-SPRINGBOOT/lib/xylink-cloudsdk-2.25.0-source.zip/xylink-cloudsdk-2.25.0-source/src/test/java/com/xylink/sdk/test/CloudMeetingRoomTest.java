package com.xylink.sdk.test;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.ConferenceMeetingRoom;
import com.xylink.model.Pager;
import com.xylink.sdk.conferenceControl.CloudMeetingRoomApi;
import com.xylink.util.Result;
import org.junit.BeforeClass;
import org.junit.Test;
import java.io.IOException;
import static org.junit.Assert.fail;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: gzm
 * Date: 2018-12-21
 */
public class CloudMeetingRoomTest {

    @BeforeClass
    public static void setup() {
//        SDKConfigMgr.setServerHost("http://172.20.11.63:8080");
//        SDKConfigMgr.setServerHost("http://127.0.0.1:8081");
    }

    @Test
    public void testGetCloudMeetingRooms() {
        CloudMeetingRoomApi cloudMeetingRoomApi = new CloudMeetingRoomApi();
        String enterpriseid = "0fd51c70dbaea818181001195fbe7d8443e59087";
        String token = "e0e2f73e2531588366a599b8dc4f1537ef85345531c0749855cf3b84ce077589";
        String type = "SDK";
        int page = 0;
        int size = 20;
        Result<Pager<ConferenceMeetingRoom>> result=null;

        try {
            result = cloudMeetingRoomApi.getCloudMeetingRooms(enterpriseid, token, type, page, size);
            System.out.println(result);
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }
}
