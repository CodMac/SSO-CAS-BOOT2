package com.xylink.sdk.test;

import com.xylink.model.Pager;
import com.xylink.model.ReminderMeeting;
import com.xylink.sdk.conferenceControl.CloudMeetingRoomApi;
import com.xylink.sdk.dating.ScheduleMeetingApi;
import com.xylink.util.Result;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.fail;

/**
 * Created by changxiangyang on 2017/9/19.
 */
public class ScheduleMeetingTest {
    private String enterpriseid=TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();
    private String meetingId = "";
    private String meetingRoomNumber = "";

    //预约会议
    @Test
    public void remindMeeting(){
        ScheduleMeetingApi sma=new ScheduleMeetingApi();
        ReminderMeeting reminderMeeting=new ReminderMeeting();
        reminderMeeting.setTitle("预约会议");
        reminderMeeting.setStartTime(System.currentTimeMillis() + (1000 * 60 * 2));
        reminderMeeting.setEndTime(System.currentTimeMillis() + (1000 * 60 * 4));
        reminderMeeting.setAddress("地中海");
        reminderMeeting.setAutoInvite(1);
        reminderMeeting.setPassword("2345");
        reminderMeeting.setMeetingRoomType(1);
        reminderMeeting.setAutoRecord(0);
        try {
            Result result = sma.remindMeeting(enterpriseid, token, reminderMeeting);
            System.out.println(result);
            //如成功后的一个示例：{"success":true,"errorStatus":200,"data":{"meetingId":"ff80808165a02ba20165cc92ef9b542c","meetingRoomNumber":"956401821"}}
        }catch (IOException e){
            System.out.println("testRemindMeeting--"+e);
        }
    }
    //修改预约会议 TODO 会议id和会议号必须是合法的，可以通过remindMeeting()方法先预约会议
    @Test
    public void updateMeeting(){
        meetingId = "ff80808165a02ba20165cc92ef9b542c";
        meetingRoomNumber = "956401821";

        ScheduleMeetingApi sma=new ScheduleMeetingApi();
        ReminderMeeting reminderMeeting=new ReminderMeeting();
        reminderMeeting.setTitle("预约会议update");
        reminderMeeting.setStartTime(System.currentTimeMillis() + (1000 * 60 * 2));
        reminderMeeting.setEndTime(System.currentTimeMillis() + (1000 * 60 * 4));
        reminderMeeting.setConferenceNumber(meetingRoomNumber);
        reminderMeeting.setAddress("地中海");
        reminderMeeting.setAutoInvite(1);
        reminderMeeting.setPassword("2345");
        reminderMeeting.setAutoRecord(0);

        try {
            Result result = sma.updateMeeting(enterpriseid, token, meetingId, reminderMeeting);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }

    //删除会议 TODO 会议id必须有效
    @Test
    public void deleteMeeting(){
        ScheduleMeetingApi sma=new ScheduleMeetingApi();
        String meetingId = "ff80808165a02ba20165cc92ef9b542c";
        try {
            Result result = sma.deleteMeeting(enterpriseid, token, meetingId);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
    //按照结束时间获取会议
    @Test
    public void getAllMeeting(){
        ScheduleMeetingApi sma=new ScheduleMeetingApi();
        long endtime = System.currentTimeMillis() + (1000 * 60 * 1);
        try {
            Result<ReminderMeeting[]> allMeeting = sma.getAllMeeting(enterpriseid, token, endtime);
            System.out.println(allMeeting);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }

    @Test
    public void getMeetingByPage() {
        ScheduleMeetingApi scheduleMeetingApi = new ScheduleMeetingApi();
        String enterpriseid = "0fd51c70dbaea818181001195fbe7d8443e59087";
        String token = "e0e2f73e2531588366a599b8dc4f1537ef85345531c0749855cf3b84ce077589";
        int page = 0;
        int size = 20;
        long endTime = 0;
        Result<Pager<ReminderMeeting>> result;

        try {
            result = scheduleMeetingApi.getMeeting(enterpriseid, token, page, size, endTime);
            System.out.println(result);
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}
