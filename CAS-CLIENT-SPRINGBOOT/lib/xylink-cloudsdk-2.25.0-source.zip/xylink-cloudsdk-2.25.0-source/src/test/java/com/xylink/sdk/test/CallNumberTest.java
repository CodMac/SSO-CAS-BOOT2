package com.xylink.sdk.test;

import com.xylink.model.CallNumberInfo;
import com.xylink.sdk.enterpriseNemo.CallNumberApi;
import com.xylink.util.Result;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by changxiangyang on 2017/9/19.
 */
public class CallNumberTest {
    //获取小鱼号信息
    @Test
    public void getCallNumberInfo(){
        CallNumberApi cna=new CallNumberApi();
        String enterpriseid = TestConfig.getInstance().getEnterpriseId();
        String token = TestConfig.getInstance().getToken();
        String number="702301";
        try {
            Result<CallNumberInfo> callNumberInfo = cna.getCallNumberInfo(enterpriseid, token, number);
            System.out.println(callNumberInfo);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
}
