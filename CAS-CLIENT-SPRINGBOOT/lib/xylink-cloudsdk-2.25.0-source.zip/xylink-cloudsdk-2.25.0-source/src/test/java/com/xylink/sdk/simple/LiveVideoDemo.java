package com.xylink.sdk.simple;

import com.xylink.model.*;
import com.xylink.sdk.conferenceControl.CreateMeetingApi;
import com.xylink.sdk.liveVideo.v3.LiveVideoApi;
import com.xylink.util.Result;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

/**
 * 直播
 * create by xinzhixuan at 2018-09-03
 */
public class LiveVideoDemo {
    private static String meetingNumber = null;// "910058204395";
    private static String liveId = null;//"ff808081659f48370165a2527ff50003";

    /**
     * 1. 创建云会议号
     * 2. 预约直播
     * 3. 在开始直播前修改直播
     * 4. 开始直播
     * 5. 结束直播
     * 6. 获取直播的视频列表
     */
    public static void main(String[] main) throws IOException, InterruptedException {
        // 云会议号不存在时创建
        if (null == meetingNumber) {
            // 创建云会议号
            SdkMeeting sdkMeeting = createRoom();
            System.out.println("云会议室：" + sdkMeeting);

            meetingNumber = sdkMeeting.getMeetingNumber();
        }

        // 没有预约直播时，可预约直播
        if (null == liveId) {
            // 预约直播
            Result<LV> lvResult = newLive(meetingNumber);
            System.out.println("预约结果：" + lvResult.toString());
            if (!lvResult.isSuccess()) {
                System.out.println("预约直播失败");
                return;
            }
            LV lv = lvResult.getData();
            liveId = lv.getLiveId();

        }
        // 查看预约直播
        Result<LiveVideoForConference> live = getLive(meetingNumber, liveId);
        System.out.println("live=" + live);

        // 修改预约直播
        Result result = updateLive(meetingNumber, liveId);
        System.out.println("更新预约结果：" + result);
        if (!result.isSuccess()) {
            System.out.println("更新预约失败");
        }

        // 查看预约直播
        live = getLive(meetingNumber, liveId);
        System.out.println("live2=" + live);

        // 删除预约直播
//        deleteLive(meetingNumber, liveId);

        // TODO 开始直播,在开始直播前需要呼云会议号
        Result start = controlLive(meetingNumber, liveId, "start");
        System.out.println("开始直播：" + start);
        if (!start.isSuccess()) {
            System.out.println("开始直播失败");
        }

        // 直播2分钟后再结束直播
        Thread.sleep(1000 * 60 * 2);
        // 结束直播，
        Result end = controlLive(meetingNumber, liveId, "end");
        System.out.println("结束直播：" + end);
        if (!end.isSuccess()) {
            System.out.println("结束直播失败");
        }

        //获取直播的视频列表
        Result<Video[]> liveVideoListResult = getLiveVideoList(meetingNumber, liveId);
        System.out.println("获取直播的视频列表:" + liveVideoListResult);
        if (!liveVideoListResult.isSuccess()) {
            System.out.println("获取直播的视频列表失败");
        }

    }

    // 获取直播的视频列表
    public static Result<Video[]> getLiveVideoList(String meetingNumber, String liveId) throws IOException {
        LiveVideoApi lva = new LiveVideoApi();
        return lva.getLiveVideoList(Config.ENTERPRISE_ID, Config.TOKEN, meetingNumber, null, liveId);
    }

    /**
     * 更新预约直播
     *
     * @param meetingNumber
     * @param liveId
     */
    public static Result updateLive(String meetingNumber, String liveId) throws IOException {
        LiveVideoApi lva = new LiveVideoApi();
        LiveVideo liveVideo = new LiveVideo();
        liveVideo.setTitle("我的预约直播更新");
        liveVideo.setAutoRecording(true);
        liveVideo.setAutoPublishRecording(true);
        return lva.updateLive(Config.ENTERPRISE_ID, Config.TOKEN, meetingNumber, null, liveId, liveVideo);
    }

    public static Result<LiveVideoForConference> getLive(String meetingNumber, String liveId) throws IOException {
        LiveVideoApi lva = new LiveVideoApi();
        return lva.getLive(Config.ENTERPRISE_ID, Config.TOKEN, meetingNumber, null, liveId);
    }

    // 创建云会议室
    public static SdkMeeting createRoom() throws IOException {
        CreateMeetingApi createMeetingApi = new CreateMeetingApi();
        SdkMeetingReq sdkMeetingReq = new SdkMeetingReq();
        sdkMeetingReq.setMeetingName("我的云会议室1");
        return createMeetingApi.createMeeting(Config.ENTERPRISE_ID, Config.TOKEN, sdkMeetingReq);
    }

    // 预约直播
    public static Result<LV> newLive(String meetingNumber) throws IOException {
        LiveVideoApi lva = new LiveVideoApi();
        com.xylink.model.LiveVideo liveVideo = new com.xylink.model.LiveVideo();
        liveVideo.setTitle("我的预约直播");
        liveVideo.setStartTime(System.currentTimeMillis() + 1000 * 60 * 20);
        liveVideo.setEndTime(System.currentTimeMillis() + 1000 * 60 * 60);
        liveVideo.setAutoRecording(true);
        liveVideo.setAutoPublishRecording(true);
        return lva.newLiveVideo(Config.ENTERPRISE_ID, Config.TOKEN, meetingNumber, liveVideo);
    }

    /**
     * 开始/结束直播
     */
    public static Result controlLive(String meetingNumber, String liveId, String status) throws IOException {
        LiveVideoApi lva = new LiveVideoApi();
        Status statusObj = new Status();
        statusObj.setStatus(status);
        return lva.controlLive(Config.ENTERPRISE_ID, Config.TOKEN, meetingNumber, null, liveId, statusObj);
    }

    // 删除预约直播
    public static void deleteLive(String meetingNumber, String liveId) throws IOException {
        LiveVideoApi lva = new LiveVideoApi();
        Result result = lva.deleteLive(Config.ENTERPRISE_ID, Config.TOKEN, null, meetingNumber, liveId);
        System.out.println("删除预约直播：" + result);
    }
}
