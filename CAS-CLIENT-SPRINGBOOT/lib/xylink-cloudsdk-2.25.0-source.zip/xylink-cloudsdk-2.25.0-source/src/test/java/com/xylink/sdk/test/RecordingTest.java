package com.xylink.sdk.test;

import com.xylink.config.SDKConfig;
import com.xylink.config.SDKConfigMgr;
import com.xylink.model.CallInviteRequest;
import com.xylink.model.DeviceInfo;
import com.xylink.model.MeetingStatus;
import com.xylink.model.RecordingResponse;
import com.xylink.model.RecordingStopResponse;
import com.xylink.model.VodInfo;
import com.xylink.sdk.conferenceControl.ConferenceControlApi;
import com.xylink.sdk.recordingControl.RecordingControlApi;
import com.xylink.sdk.vod.VodApi;
import com.xylink.util.Result;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import javax.xml.transform.Source;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.fail;

/**
 * Created by wenya on 17/9/25.
 */
public class RecordingTest {

    private String enterpriseid = TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();
    private String callNumber = "";

    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://sdk.xylink.com");
//        SDKConfigMgr.setServerHost("http://127.0.0.1:8081");
    }

    // TODO 注意：会议号必须有效，且已经有人加入才可录制
    @Test
    public void testStartRecord() {
        callNumber = "910067892539";

        RecordingControlApi recordingControlApi = new RecordingControlApi();
        try {
            Result result = recordingControlApi.startRecording(TestConfig.getInstance().getEnterpriseId(),
                    TestConfig.getInstance().getToken(), callNumber);
            System.out.println("开始录制结果：" + result);
            Assert.assertEquals(200, result.getErrorStatus());
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
            }
            Result<RecordingResponse> recordingResponseResult = recordingControlApi.stopRecording(TestConfig.getInstance().getEnterpriseId(),
                    TestConfig.getInstance().getToken(), callNumber);
            System.out.println("停止录制的结果：" + recordingResponseResult);
        } catch (IOException e) {
            fail(e.getMessage());
        }

        // 结束会议
        end();
    }

    // 查看会议状态 TODO 会议号必须有效
    @Test
    public void getMeetingStatus() {
        callNumber = "910075217386";
        ConferenceControlApi cca = new ConferenceControlApi();
        try {
            Result<MeetingStatus> result = cca.getMeetingStatus(enterpriseid, token, callNumber);
            System.out.println(result);
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }

    // 邀请入会 TODO 会议号必须有效，邀请入会的设备号必须也有效，且在自己的企业下
    @Test
    public void inviteCall() {
        callNumber = "910075217386";

        ConferenceControlApi cca = new ConferenceControlApi();
        CallInviteRequest callInviteRequest = new CallInviteRequest();
        List<DeviceInfo> devices = new ArrayList<DeviceInfo>();
        DeviceInfo device = new DeviceInfo();
        device.setNumber("782165");
        devices.add(device);
        callInviteRequest.setCallNumber(callNumber);
        callInviteRequest.setDeviceList(devices);

        try {
            Result result = cca.inviteCall(enterpriseid, token, callInviteRequest);
            System.out.println(result);
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }

    // 结束会议
    private void end() {
        ConferenceControlApi cca = new ConferenceControlApi();
        try {
            Result result = cca.end(enterpriseid, token, callNumber);
            System.out.println("结束会议：" + result);
        } catch (IOException e) {
            System.out.println("testEnd--" + e);
        }
    }

    @Test
    public void stopRecording() throws IOException {
        RecordingControlApi recordingControlApi = new RecordingControlApi();
        Result<RecordingResponse> result = recordingControlApi.stopRecording(TestConfig.getInstance().getEnterpriseId(),
                TestConfig.getInstance().getToken(), callNumber);
        System.out.println(result);
    }

    @Test
    public void stopRecordingWithSessionId() throws IOException {
        RecordingControlApi recordingControlApi = new RecordingControlApi();
        Result<RecordingStopResponse> result = recordingControlApi.stopRecordingWithSessionId(TestConfig.getInstance().getEnterpriseId(),
                TestConfig.getInstance().getToken(), callNumber);
        System.out.println(result);
    }

    @Test
    public void getMeetingRoomVods() throws IOException {
        callNumber = "910067892539";
        VodApi vodApi = new VodApi();
        Result<VodInfo[]> result = vodApi.getMeetingRoomVods(enterpriseid, token, callNumber, null, null);
        System.out.println(result);
    }

    @Test
    public void getDownloadurl() throws IOException {
        String vodId = "1643953";
        VodApi vodApi = new VodApi();
        Result result = vodApi.getDownloadurl(enterpriseid, token, vodId);
        System.out.println(result);
    }

    @Test
    public void getDownloadurlBySessionId() throws IOException {
        String sessionId = "1643953";
        VodApi vodApi = new VodApi();
        Result result = vodApi.getDownloadurlBySessionId(enterpriseid, token, sessionId);
        System.out.println(result);
    }
}
