package com.xylink.sdk.test;

import com.xylink.model.DeviceInfo;
import com.xylink.model.Pager;
import com.xylink.sdk.device.DeviceStatusApi;
import com.xylink.util.Result;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by changxiangyang on 2017/9/19.
 */
public class DeviceStatusTest {
    private String enterpriseid = TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();

    // 获取所有的鱼
    @Test
    public void getDeviceInfo(){
        DeviceStatusApi dsa=new DeviceStatusApi();
        try {
            Result<DeviceInfo[]> deviceInfo = dsa.getDeviceInfo(enterpriseid, token);
            System.out.println(deviceInfo);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
    //获取所有鱼类状态
    @Test
    public void getDeviceInfos(){
        DeviceStatusApi dsa=new DeviceStatusApi();
        try {
            Result<DeviceInfo[]> deviceInfo = dsa.getDeviceInfo(enterpriseid, token);
            System.out.println(deviceInfo);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }

    @Test
    public void getDeviceInfosByPage(){
        DeviceStatusApi dsa=new DeviceStatusApi();
        String enterpriseid = "f3c422a7c36eac6c924ed2a50eb4f49f82b128de";
        String token = "a727338bb95fb608dde30774a96ae712c4a71ab3a4d6b499282048852bfe5a43";
        int page = 0;
        int size = 20;
        try {
            Result<Pager<DeviceInfo>> deviceInfo = dsa.getDeviceInfo(enterpriseid, token, page, size);
            System.out.println(deviceInfo);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }

    //通过sn列表查询设备信息
    @Test
    public void getDeviceInfoBySn(){
        DeviceStatusApi dsa=new DeviceStatusApi();
        List<String> snLst=new ArrayList<String>();
        snLst.add("2D1510907");
        try {
            Result<DeviceInfo[]> deviceInfo = dsa.getDeviceInfo(enterpriseid, token, snLst);
            System.out.println(deviceInfo);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
}
