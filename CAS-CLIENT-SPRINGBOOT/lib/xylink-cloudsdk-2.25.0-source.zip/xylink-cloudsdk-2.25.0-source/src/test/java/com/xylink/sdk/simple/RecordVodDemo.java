package com.xylink.sdk.simple;

/**
 * 视频录制
 * create by xinzhixuan at 2018-08-28
 */
public class RecordVodDemo {

    /**
     * 录制会议视频（前提条件：会议已经开启，即存在有效的云会议号）
     * 1. 开始录制
     * 2. 结束录制（结束后会返回一个对应的视频下载的url）
     * 3. 会议期间会存在录制多个视频的情况，可查看当前会议号下对应的所有录制的视频
     * 4. 通过视频的id获取下载视频的url
     * 5. 通过下载视频url或第2步返回的url可以下载具体的视频
     */
    public static void main(String[] args) {
        // 1.开始录制

    }
}
