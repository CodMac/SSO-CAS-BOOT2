package com.xylink.sdk.test;


import com.xylink.config.SDKConfigMgr;
import com.xylink.model.ExternalLoginRequest;
import com.xylink.model.SdkMiniProgramUserDto;
import com.xylink.model.UserValidateResponse;
import com.xylink.sdk.user.UserValidateApi;
import com.xylink.sdk.wechat.MiniProgramApi;
import com.xylink.util.AES256Util;
import com.xylink.util.Result;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.fail;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: gzm
 * Date: 2018-12-08
 */
public class WechatTest {

    private String enterpriseid= TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();

    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://sdk.xylink.com");
    }

    @Test
    public void batchUser() {
        enterpriseid = "249138e9aa104dc0cb98be685939a3d8756ab5ff";
        token = "681e5ddca4f8ed387ecb17c293eaf5c24945edbcbec67272dab1c3066c72954f";
        MiniProgramApi miniProgramApi = new MiniProgramApi();

        try {
            Result<List<SdkMiniProgramUserDto>> result = miniProgramApi.batchUser(enterpriseid,token,"wx3f80ccce4824ae8c");
            System.out.println(result.getData());
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }

}
