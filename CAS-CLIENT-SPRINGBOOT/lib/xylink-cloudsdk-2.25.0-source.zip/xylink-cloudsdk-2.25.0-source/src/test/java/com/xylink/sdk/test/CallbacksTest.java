package com.xylink.sdk.test;

import com.xylink.model.VodInfo;
import com.xylink.model.callback.CallbackEvent;
import com.xylink.model.callback.ExternalCallback;
import com.xylink.model.callback.RosterCallback;
import com.xylink.sdk.callback.CallBacksApi;
import com.xylink.util.Result;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: gzm
 * Date: 2018-08-02
 */
public class CallbacksTest {

    private String enterpriseid= "f3c422a7c36eac6c924ed2a50eb4f49f82b128de";//TestConfig.getInstance().getEnterpriseId();
    private String token = "a727338bb95fb608dde30774a96ae712c4a71ab3a4d6b499282048852bfe5a43";//TestConfig.getInstance().getToken();


    @Test
    public void getExternalCallbacks(){
        CallBacksApi callBacksApi = new CallBacksApi();
        Result<ExternalCallback[]> result = null;
        try{
            result = callBacksApi.getExternalCallbacks(enterpriseid, token);
            System.out.println(result);
        }catch(Exception e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);

    }

    @Test
    public void regExternalCallback(){
        CallBacksApi callBacksApi = new CallBacksApi();
        Result<ExternalCallback[]> result = null;
        try{
            ExternalCallback externalCallback = new ExternalCallback(CallbackEvent.LiveStatus, "");
            result = callBacksApi.regExternalCallback(enterpriseid, token, externalCallback);
            System.out.println(result);
        }catch(Exception e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);

    }

    @Test
    public void updateExternalCallbacks(){
        CallBacksApi callBacksApi = new CallBacksApi();
        Result<ExternalCallback[]> result = null;
        try{
            ExternalCallback externalCallback = new ExternalCallback(CallbackEvent.LiveStatus, "123");
            result = callBacksApi.updateExternalCallback(enterpriseid, token, externalCallback);
            System.out.println(result);
        }catch(Exception e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);

    }

    @Test
    public void removeExternalCallback(){
        CallBacksApi callBacksApi = new CallBacksApi();
        Result<ExternalCallback[]> result = null;
        try{
            result = callBacksApi.removeExternalCallback(enterpriseid, token, CallbackEvent.LiveStatus);
            System.out.println(result);
        }catch(Exception e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);

    }

    @Test
    public void getRosterCallbacks(){
        CallBacksApi callBacksApi = new CallBacksApi();
        Result<RosterCallback[]> result = null;
        try{
            result = callBacksApi.getRosterCallbacks(enterpriseid, token);
            System.out.println(result);
        }catch(Exception e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);

    }

    @Test
    public void regRosterCallback(){
        String confNumber = "9000392313";
        CallBacksApi callBacksApi = new CallBacksApi();
        Result<RosterCallback[]> result = null;
        try{
            RosterCallback rosterCallback = new RosterCallback(confNumber, CallbackEvent.ConferenceRosterInfo, "https://www.xylink.com");
            result = callBacksApi.regRosterCallback(enterpriseid, token, confNumber, rosterCallback);
            System.out.println(result);
        }catch(Exception e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);

    }

    @Test
    public void removeRosterCallback(){
        String confNumber = "9000392313";
        CallBacksApi callBacksApi = new CallBacksApi();
        Result<RosterCallback[]> result = null;
        try{
            result = callBacksApi.removeRosterCallback(enterpriseid, token, confNumber);
            System.out.println(result);
        }catch(Exception e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);

    }
}
