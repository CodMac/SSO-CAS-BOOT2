package com.xylink.sdk.test;


import com.xylink.config.SDKConfigMgr;
import com.xylink.model.*;
import com.xylink.model.statis.CurrentMeetingDetail;
import com.xylink.model.statis.MeetingParticipant;
import com.xylink.sdk.conferenceControl.ConferenceControlApi;
import com.xylink.sdk.conferenceControl.CreateMeetingApi;
import com.xylink.sdk.dating.ScheduleMeetingApi;
import com.xylink.util.Result;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by wenya on 17/9/13.
 */
public class ConferenceControlTest {

    private static SdkMeeting sdkMeeting = null;
    private String enterpriseid= TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();
    // 保证有效
    private String callNumber ="";
    private String nemoNumber ="";

    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://sdk.xylink.com");
//        SDKConfigMgr.setServerHost("http://127.0.0.1:8081");
    }

    @Test
    public void testCreateRoom() {
        CreateMeetingApi createMeetingApi = new CreateMeetingApi();
        SdkMeetingReq sdkMeetingReq = new SdkMeetingReq();
        sdkMeetingReq.setMeetingName("test");
        try {
            sdkMeeting = createMeetingApi.createMeeting(enterpriseid, token,
                    sdkMeetingReq);
            assertNotNull(sdkMeeting);
            assertNotNull(sdkMeeting.getMeetingNumber());
        } catch (IOException e) {
            fail(e.getMessage());
        }
    }

    //  需要保证云会议号和小鱼号有效,且小鱼在该企业下
    @Test
    public void InviteCall() {
        callNumber ="910037036918";
        nemoNumber = "101.231.223.66##119913##1010";
        ConferenceControlApi cca=new ConferenceControlApi();

        CallInviteRequest callInviteRequest=new CallInviteRequest();
        List<DeviceInfo> devices=new ArrayList<DeviceInfo>();
        DeviceInfo device=new DeviceInfo();
        device.setNumber(nemoNumber);
        devices.add(device);
        callInviteRequest.setCallNumber(callNumber);
        callInviteRequest.setDeviceList(devices);
        Result result=null;
        try {
            result = cca.inviteCall(enterpriseid, token, callInviteRequest);
            System.out.println(result);
        }catch (IOException e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);
    }
    @Test
    public void getMeetingStatus(){
        callNumber = "910031562976";
        ConferenceControlApi cca=new ConferenceControlApi();
        try {
             Result<MeetingStatus> meetingStatus = cca.getMeetingStatus(enterpriseid, token, callNumber);
            System.out.println(meetingStatus);
             assertNotNull(meetingStatus);
        }catch (IOException e){
            fail(e.getMessage());
        }
    }

    //邀请一个设备进入会议，设备必须在该企业下
    @Test
    public void inviteNemoCall(){
        callNumber ="9000292495";
        nemoNumber = "36.110.14.190";
        ConferenceControlApi cca=new ConferenceControlApi();

        MeetingRoom  meetingRoomNo =new MeetingRoom();
        meetingRoomNo.setMeetingRoomNumber(callNumber);
        Result result=null;
        try {
            result= cca.inviteNemoCall(enterpriseid, token, nemoNumber,meetingRoomNo);
            System.out.println(result);
        }catch (IOException e){
            e.printStackTrace();
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        assertTrue(isSuccess);
    }

    //设置主画面
    @Test
    public void setMainImage(){
        callNumber ="910056972431";
        nemoNumber = "782165";

        ConferenceControlApi cca=new ConferenceControlApi();
        String meetingRoomNo = callNumber;
        Device device =new Device();
        device.setId(100120772);
        device.setType(2);
        device.setParticipantNumber(nemoNumber);
        device.setExternalUserId(null);
        Result result=null;
        try {
            result = cca.setMainImage(enterpriseid, token, meetingRoomNo,device);
            System.out.println(result);
        }catch (IOException e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        assertTrue(isSuccess);
    }

    //获取某公司当前正在进行的会议
    @Test
    public void getEnterpriseCurrentMeeting(){
        enterpriseid = "e1192cef19a82984888a55eaf31d4abd19466d05";
        token = "d26f19e3569cdb2892dae5ed437ebad4fbe38877cb0440e093979634f38c8e0e";
        ConferenceControlApi cca=new ConferenceControlApi();
        Result<CurrentMeeting[]> result=null;
        try {
            result = cca.getEnterpriseCurrentMeeting(enterpriseid, token);
            System.out.println(result);
        }catch (IOException e){
            e.printStackTrace();
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        assertTrue(isSuccess);
        CurrentMeeting [] currentMeetings= result.getData();
        for(CurrentMeeting currentMeeting:currentMeetings){
            System.out.println("===="+currentMeeting.getMeetingRoomNumber());
        }
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }

    @Test
    public void getEnterpriseCurrentMeetingByPage() {
        ConferenceControlApi conferenceControlApi = new ConferenceControlApi();
        String enterpriseid = "f3c422a7c36eac6c924ed2a50eb4f49f82b128de";
        String token = "a727338bb95fb608dde30774a96ae712c4a71ab3a4d6b499282048852bfe5a43";
        int page = 0;
        int size = 20;
        Result<Pager<CurrentMeeting>> result;

        try {
            result = conferenceControlApi.getEnterpriseCurrentMeeting(enterpriseid, token, page, size);
            System.out.println(result);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    @Test
    public void getCurrentMeetingParticipantByPage() {
        ConferenceControlApi conferenceControlApi = new ConferenceControlApi();
        String enterpriseid = "f3c422a7c36eac6c924ed2a50eb4f49f82b128de";
        String token = "a727338bb95fb608dde30774a96ae712c4a71ab3a4d6b499282048852bfe5a43";
        int page = 0;
        int size = 20;
        String meetingId = "1151637296210";
        Result<Pager<MeetingParticipant>> result;

        try {
            result = conferenceControlApi.getCurrentMeetingParticipant(enterpriseid, token, page, size, meetingId);
            System.out.println(result);
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    //根据云会议号获取某公司当前正在进行的会议
    @Test
    public void getEnterpriseCurrentMeetingByNum(){
        enterpriseid = "e1192cef19a82984888a55eaf31d4abd19466d05";
        token = "d26f19e3569cdb2892dae5ed437ebad4fbe38877cb0440e093979634f38c8e0e";
        callNumber ="9001631835";
        ConferenceControlApi cca=new ConferenceControlApi();
        Result<CurrentMeeting> result=null;
        try {
            result = cca.getEnterpriseCurrentMeeting(enterpriseid, token,callNumber);
            System.out.println(result);
        }catch (IOException e){
            e.printStackTrace();
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        assertTrue(isSuccess);
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }

    //静音
    @Test
    public void mute(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        Device device=new Device();
        device.setId(100120772);
        device.setType(2);
        device.setParticipantId("393344");
        device.setParticipantNumber("702301");
        device.setExternalUserId(null);
        Device[] devices={device};
        Result result=null;
        try {
            result = cca.mute(enterpriseid, token,callNumber,devices);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testMute--"+e);
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }
    //全部静音
    @Test
    public void muteall(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        Result result=null;
        try {
            result = cca.muteall(enterpriseid, token,callNumber);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testMuteall--"+e);
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }
    //取消静音
    @Test
    public void unmute(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        Device device=new Device();
        device.setId(100120772);
        device.setType(2);
        device.setParticipantId("393344");
        device.setParticipantNumber("702301");
        device.setExternalUserId(null);
        Device[] devices={device};
        Result result=null;
        try {
            result = cca.unmute(enterpriseid, token,callNumber,devices);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testUnmute--"+e);
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }
    //结束会议
    @Test
    public void end(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        Result result=null;
        try {
            result =
                    cca.end(enterpriseid, token,callNumber);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }
    //结束会议
    @Test
    public void endandrelease(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        Result result=null;
        try {
            result = cca.endAndReleaseNumber(enterpriseid, token,callNumber);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }
    //发通知
    @Test
    public void notifyDevice(){
        ConferenceControlApi cca=new ConferenceControlApi();
        Device device=new Device();
        device.setId(100120772);
        device.setType(2);
        device.setParticipantId("393344");
        device.setParticipantNumber("702301");
        device.setExternalUserId(null);
        List<Device> devices=new ArrayList<Device>();
        devices.add(device);
        DeviceNotification deviceNotification=new DeviceNotification();
        deviceNotification.setDeviceList(devices);
        deviceNotification.setContent("我二哈恶搞");
        deviceNotification.setNotificationType(1);
        Result result=null;
        try {
            result = cca.notifyDevice(enterpriseid, token,deviceNotification);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }
    //授权分享权限
    @Test
    public void contentAuthShare(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        ShareAuthTarget sat=new ShareAuthTarget();
        Device device=new Device();
        device.setId(100120772);
        device.setType(2);
        device.setParticipantId("393344");
        device.setParticipantNumber("702301");
        device.setExternalUserId(null);
        Device[] devices={device};
        sat.setIsAll(false);
        sat.setDevice(device);
        Result result=null;
        try {
            result = cca.authShare(enterpriseid, token,callNumber,sat);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
        if(result!=null) {
            int errStatus = result.getErrorStatus();
            boolean isSuccess = result.isSuccess();
            if (errStatus < 300) {
                System.out.println("测试成功！" + errStatus);
            } else {
                System.out.println("测试失败！" + errStatus);
            }
        }
    }
    //会议锁定
    @Test
    public void lock(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        Result result=null;
        try {
            result = cca.meetingLock(enterpriseid, token, callNumber);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }
    //会议解锁
    @Test
    public void unlock(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        Result result=null;
        try {
            result = cca.meetingUnlock(enterpriseid, token,callNumber);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
        int errStatus = result.getErrorStatus();
        boolean isSuccess = result.isSuccess();
        if(errStatus<300){
            System.out.println("测试成功！"+errStatus);
        }else {
            System.out.println("测试失败！"+errStatus);
        }
    }
    //发送消息
    @Test
    public void sendMsg(){
        callNumber ="910056972431";
        ConferenceControlApi cca=new ConferenceControlApi();
        MeetingSubtitleRequest msr=new MeetingSubtitleRequest();
        Device device=new Device();
        device.setId(100120772);
        device.setType(2);
        device.setParticipantId("393344");
        device.setParticipantNumber("702301");
        device.setExternalUserId(null);
        Device[] devices={device};
        msr.setDevices(devices);
        MeetingSubtitle meetingSubtitle =new MeetingSubtitle();
        meetingSubtitle.setContent("发月闭关！！！");
        meetingSubtitle.setLocation("middle");
        meetingSubtitle.setAction("cancel");
        meetingSubtitle.setScroll("1");
        msr.setMeetingSubtitle(meetingSubtitle);
        Result result=null;
        try {
            result = cca.sendMessage(enterpriseid, token,callNumber, msr);
            System.out.println(result);
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
        if(result!=null) {
            int errStatus = result.getErrorStatus();
            boolean isSuccess = result.isSuccess();
            if (errStatus < 300) {
                System.out.println("测试成功！" + errStatus);
            } else {
                System.out.println("测试失败！" + errStatus);
            }
        }
    }
    //删除人员：在会议过程中删除与会人员
    @Test
    public void disconnect(){
        callNumber ="910037036918";
        ConferenceControlApi cca=new ConferenceControlApi();
        Device device =new Device();
//        device.setId(100120772);
        device.setType(6);
//        device.setParticipantId("36.110.14.190");
//        device.setParticipantNumber("36.110.14.190##1810");
        device.setParticipantNumber("101.231.223.66##119913##1010");
//        device.setExternalUserId(null);
        Device[] devices={device};
        Result result=null;
        try {
            result = cca.disconnect(enterpriseid, token, callNumber,devices);
            System.out.println(result);
        }catch (IOException e){
            fail(e.getMessage());
        }
    }

    @Test
    public void disconnect2(){
        callNumber ="910037036918";
        ConferenceControlApi cca=new ConferenceControlApi();
        List list = new ArrayList();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("type", 6);
        map.put("participantNumber", "101.231.223.66##119913##1010");
        list.add(map);
        Result result=null;
        try {
            result = cca.disconnect(enterpriseid, token, callNumber, new ObjectMapper().writeValueAsString(list));
            System.out.println(result);
        }catch (IOException e){
            fail(e.getMessage());
        }
    }

    /**
     * 获取某公司当前正在进行的会议(包括会议质量和参会方质量)
     */
    @Test
    public void getEnterpriseCurrentMeetingDetail() {
        enterpriseid = "e1192cef19a82984888a55eaf31d4abd19466d05";
        token = "d26f19e3569cdb2892dae5ed437ebad4fbe38877cb0440e093979634f38c8e0e";
        ConferenceControlApi cca=new ConferenceControlApi();
        try {
            Result<CurrentMeetingDetail[]> result = cca.getEnterpriseCurrentMeetingDetail(enterpriseid, token, false);
            System.out.println(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取某公司特定的正在进行的会议(包括会议质量和参会方质量)
     * 注意：  当前会议必须正在开会中
     */
    @Test
    public void getEnterpriseCurrentSpecificMeetingDetail() {
        enterpriseid = "e1192cef19a82984888a55eaf31d4abd19466d05";
        token = "d26f19e3569cdb2892dae5ed437ebad4fbe38877cb0440e093979634f38c8e0e";
        callNumber ="9001631835";
        ConferenceControlApi cca=new ConferenceControlApi();
        try {
            Result<CurrentMeetingDetail> result = cca.getEnterpriseCurrentSpecificMeetingDetail(enterpriseid, token, callNumber, true);
            System.out.println(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 会议中挂断终端
     */
    @Test
    public void hangUp() {
        nemoNumber = "782165";
        ConferenceControlApi cca=new ConferenceControlApi();
        try {
            Result result = cca.hangUp(enterpriseid, token, nemoNumber);
            System.out.println(result);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 开始多画面及广播
     * {
     * "deviceId": 36145,
     *  "type": 8,
     *  "broadcast": false,
     *  "mlayout": {
     *  "mode": "2-1"}
     *
     * }
     */
    @Test
    public void startDeviceMultiImage(){
        callNumber = "9379073038";
        enterpriseid = "7daf952d71c87b962ea3dc3209b3969d2c75c4d0";
        token = "f3ff9ad1dbbf80f553dceb810c32d3092a8da7477ee2ebff568fe6a3646b208b";
        ConferenceControlApi cca=new ConferenceControlApi();
        DeviceMultiImageRequest deviceMultiImageRequest = new DeviceMultiImageRequest();
        try{
            deviceMultiImageRequest.setDeviceId(60924763);
            deviceMultiImageRequest.setType(7);
            deviceMultiImageRequest.setBroadcast(false);
            MlayoutResquest mlayoutResquest = new MlayoutResquest();
            mlayoutResquest.setMode("3-1");
            deviceMultiImageRequest.setMlayout(mlayoutResquest);
            Result result = cca.startDeviceMultiImage(enterpriseid, token, callNumber, deviceMultiImageRequest);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 停止多画面及广播
     */
    @Test
    public void stopDeviceMultiImage(){
        callNumber = "9379073038";
        enterpriseid = "7daf952d71c87b962ea3dc3209b3969d2c75c4d0";
        token = "f3ff9ad1dbbf80f553dceb810c32d3092a8da7477ee2ebff568fe6a3646b208b";
        ConferenceControlApi cca=new ConferenceControlApi();
        DeviceMultiImageRequest deviceMultiImageRequest = new DeviceMultiImageRequest();
        deviceMultiImageRequest.setDeviceId(60924763);
        deviceMultiImageRequest.setType(7);
        try{
            Result result = cca.stopDeviceMultiImage(enterpriseid, token, callNumber, deviceMultiImageRequest);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 向终端发送字幕
     */
    @Test
    public void subtitle(){
        callNumber = "9379073038";
        enterpriseid = "7daf952d71c87b962ea3dc3209b3969d2c75c4d0";
        token = "f3ff9ad1dbbf80f553dceb810c32d3092a8da7477ee2ebff568fe6a3646b208b";
        ConferenceControlApi cca=new ConferenceControlApi();
        MeetingControlSubtitleRequest meetingControlSubtitleRequest = new MeetingControlSubtitleRequest();
        meetingControlSubtitleRequest.setContent("test content subtitle");
        MeetingControlSubtitleRequest.TargetsBean targetsBean = new MeetingControlSubtitleRequest.TargetsBean();
        targetsBean.setDeviceId(60924763);
        targetsBean.setDeviceType(7);
        List<MeetingControlSubtitleRequest.TargetsBean> targetsBeans = new ArrayList<MeetingControlSubtitleRequest.TargetsBean>();
        meetingControlSubtitleRequest.setTargets(targetsBeans);
        try{
            Result result = cca.subtitle(enterpriseid, token, callNumber, meetingControlSubtitleRequest);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 直播中  设置直播内容布局
     */
    @Test
    public void liveContentLayout(){
        callNumber = "9379073038";
        enterpriseid = "7daf952d71c87b962ea3dc3209b3969d2c75c4d0";
        token = "f3ff9ad1dbbf80f553dceb810c32d3092a8da7477ee2ebff568fe6a3646b208b";
        ConferenceControlApi cca=new ConferenceControlApi();
        LiveLayoutRequest liveLayoutRequest = new LiveLayoutRequest();
        liveLayoutRequest.setContentLayout(LiveContentLayoutType.MONO);
        liveLayoutRequest.setMainImageId(60924763);
        liveLayoutRequest.setMainImageType(7);
        try{
            Result result = cca.liveContentLayout(enterpriseid, token, callNumber, liveLayoutRequest);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 直播中  设置直播人物布局
     */
    @Test
    public void livePeopleLayout(){
        callNumber = "9379073038";
        enterpriseid = "7daf952d71c87b962ea3dc3209b3969d2c75c4d0";
        token = "f3ff9ad1dbbf80f553dceb810c32d3092a8da7477ee2ebff568fe6a3646b208b";
        ConferenceControlApi cca=new ConferenceControlApi();
        LiveLayoutRequest liveLayoutRequest = new LiveLayoutRequest();
        liveLayoutRequest.setPeopleLayoutType(LivePeopleLayoutType.MULTI);
        liveLayoutRequest.setMainImageId(60924763);
        liveLayoutRequest.setMainImageType(7);
        try{
            Result result = cca.livePeopleLayout(enterpriseid, token, callNumber, liveLayoutRequest);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
