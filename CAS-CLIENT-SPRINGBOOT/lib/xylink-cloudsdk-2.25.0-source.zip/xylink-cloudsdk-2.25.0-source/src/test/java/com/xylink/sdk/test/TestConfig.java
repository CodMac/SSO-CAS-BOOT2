package com.xylink.sdk.test;

/**
 * Created by wenya on 17/9/13.
 */
public class TestConfig {

    private final String enterpriseId;

    private final String token;

    private static TestConfig testConfig = new TestConfig("12e53a6df2e91e6177e627c8e336a6888ff98104","a8208f6495ba1d468343cc63c13c5202837b5ba8614bdc699f46e91b4df09fd0");
//    private static TestConfig testConfig = new TestConfig("3671473d0f3b155560b67c1b7a840fc266bb6aab","72de07efe4d2ddcd568ce2d125ebbd185b4a28a3d12122db01b2b7d54ec666cb");

    private TestConfig(String enterpriseId, String token) {
        this.enterpriseId = enterpriseId;
        this.token = token;
    }

    public static TestConfig getInstance() {
        return testConfig;
    }

    public String getEnterpriseId() {
        return enterpriseId;
    }

    public String getToken() {
        return token;
    }
}
