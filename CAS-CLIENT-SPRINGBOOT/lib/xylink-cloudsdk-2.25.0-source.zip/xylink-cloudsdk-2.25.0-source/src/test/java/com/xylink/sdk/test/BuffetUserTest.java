package com.xylink.sdk.test;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.BuffetUserDto;
import com.xylink.user.BuffetUserApi;
import com.xylink.util.Result;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by changxiangyang on 2017/11/1.
 */
public class BuffetUserTest {
    private String enterpriseId= TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();

    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://sdk.xylink.com");
//        SDKConfigMgr.setServerHost("http://127.0.0.1:8081");
    }

//    @Test
    public void batchAdd(){
        BuffetUserApi bua=new BuffetUserApi();
        List<BuffetUserDto> buffetUserDtoList=new ArrayList<BuffetUserDto>();
        BuffetUserDto buffetUserDto=new BuffetUserDto();
        buffetUserDto.setName("敦也");
        buffetUserDto.setPhone("15811043667");
        buffetUserDto.setMailbox("feiliwushi@sina.com");
        buffetUserDto.setCountryCode("+86");
        buffetUserDto.setAvatar("http://we.com/0_0.jpg");
        buffetUserDto.setDept("销售部");
        buffetUserDto.setPassword("234567");
        buffetUserDtoList.add(buffetUserDto);
        BuffetUserDto buffetUserDto1=new BuffetUserDto();
        buffetUserDto1.setName("飞镖超人");
        buffetUserDto1.setPhone("15811043786");
        buffetUserDto1.setMailbox("xiangtai@sina.com");
        buffetUserDto1.setCountryCode("+86");
        buffetUserDto1.setAvatar("http://we.com/343.jpg");
        buffetUserDto1.setDept("销售部");
        buffetUserDto1.setPassword("255555");
        buffetUserDtoList.add(buffetUserDto1);
        try {
            Result<Set> userInfos = bua.batchAdd(buffetUserDtoList, "fadfadfadfasdfadsfasdfa", "fsdfasjdfkajfkadfajdfajf");
            int errStatus =userInfos.getErrorStatus();
            if (errStatus<300) {
                System.out.println("batchAddUserInfo测试成功！");
            }else {
                System.out.println("batchAddUserInfo测试失败！");
            }
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
//    @Test
    public void get(){
        BuffetUserApi bua=new BuffetUserApi();
        try {
            Result<List> userInfo= bua.get("fadfadfadfasdfadsfasdfa", "fsdfasjdfkajfkadfajdfajf");
            int errStatus =userInfo.getErrorStatus();
            if (errStatus<300) {
                System.out.println("getUserInfo测试成功！");
            }else {
                System.out.println("getUserInfo测试失败！");
            }
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
    @Test
    public void add(){
        BuffetUserApi bua=new BuffetUserApi();
        BuffetUserDto buffetUserDto=new BuffetUserDto();
        buffetUserDto.setUserId("00000000001");
        buffetUserDto.setName("xinzhixuan");
        buffetUserDto.setPhone("11111111112");
//        buffetUserDto.setMailbox("xiangtai@sina.com");
        buffetUserDto.setCountryCode("+86");
//        buffetUserDto.setAvatar("http://we.com/343.jpg");
//        buffetUserDto.setDept("销售部");
//        buffetUserDto.setPassword("255555");
        try {
            Result<Map> userInfo= bua.add(buffetUserDto, enterpriseId, token);
            System.out.println("result:" + userInfo);
            int errStatus =userInfo.getErrorStatus();
            if (errStatus<300) {
                System.out.println("addUserInfo测试成功！");
            }else {
                System.out.println("addUserInfo测试失败！");
            }
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
    @Test
    public void update(){
        BuffetUserApi bua=new BuffetUserApi();
        BuffetUserDto buffetUserDto=new BuffetUserDto();
        buffetUserDto.setName("敦已");
        buffetUserDto.setPhone("15811043667");
        buffetUserDto.setMailbox("dunda@sina.com");
        buffetUserDto.setCountryCode("+86");
        try {
            Result result= bua.update(buffetUserDto, "fadfadfadfasdfadsfasdfa", "fsdfasjdfkajfkadfajdfajf");
            int errStatus =result.getErrorStatus();
            if (errStatus<300) {
                System.out.println("updateUserInfo测试成功！");
            }else {
                System.out.println("updateUserInfo测试失败！");
            }
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
//    @Test
    public void delete(){
        BuffetUserApi bua=new BuffetUserApi();
        try {
            Result result= bua.delete("fadfadfadfasdfadsfasdfa", "fsdfasjdfkajfkadfajdfajf" ,"", "");
            int errStatus =result.getErrorStatus();
            if (errStatus<300) {
                System.out.println("deleteUserInfo测试成功！");
            }else {
                System.out.println("deleteUserInfo测试失败！");
            }
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
}
