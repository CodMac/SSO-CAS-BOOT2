package com.xylink.sdk.simple;

import com.xylink.model.ReminderMeeting;
import com.xylink.sdk.dating.ScheduleMeetingApi;
import com.xylink.util.Result;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

/**
 * 预约会议
 * create by xinzhixuan at 2018-09-03
 */
public class ScheduleMeetingDemo {

    /**
     * 1. 预约会议
     * 2. 修改预约会议
     * 3. 获取所有企业的预约会议记录
     * 4. 删除会议
     */
    public static void main(String[] args) throws IOException {
        // 预约会议
        Result result = remindMeeting();
        System.out.println("预约：" + result);
        if (!result.isSuccess()) {
            System.out.println("预约会议失败");
            return;
        }
        Map data = (Map) result.getData();
        String meetingId = data.get("meetingId").toString();
        String meetingRoomNumber = data.get("meetingRoomNumber").toString();


        // 修改预约会议
        result = updateMeeting(meetingId, meetingRoomNumber);
        System.out.println("修改：" + result);
        if (!result.isSuccess()) {
            System.out.println("修改预约会议失败");
            return;
        }
        // 获取所有企业的预约会议记录
        Result<ReminderMeeting[]> result2 = getAllMeeting();
        if (!result2.isSuccess()) {
            System.out.println("查询预约会议失败");
            return;
        }
        System.out.println("查询：" + Arrays.toString(result2.getData()));

        // 删除会议
        result = deleteMeeting(meetingId);
        System.out.println("删除:" + result);
        if (result.isSuccess()) {
            System.out.println("删除预约会议成功");
        } else {
            System.out.println("删除预约会议失败");
        }
    }

    public static Result remindMeeting() throws IOException {
        ScheduleMeetingApi sma = new ScheduleMeetingApi();
        ReminderMeeting reminderMeeting = new ReminderMeeting();
        reminderMeeting.setTitle("我预约的会议");
        // 开始时间，2个min之后
        reminderMeeting.setStartTime(System.currentTimeMillis() + (1000 * 60 * 2));
        // 结束时间，4个min之后，预约会议时长2min
        reminderMeeting.setEndTime(System.currentTimeMillis() + (1000 * 60 * 4));
        reminderMeeting.setAddress("地中海");
        reminderMeeting.setAutoInvite(1);
        reminderMeeting.setPassword("2345");
        reminderMeeting.setAutoRecord(0);
        reminderMeeting.setMeetingRoomType(1);
        return sma.remindMeeting(Config.ENTERPRISE_ID, Config.TOKEN, reminderMeeting);
    }

    //修改预约会议
    public static Result updateMeeting(String meetingId, String meetingRoomNumber) throws IOException {
        ScheduleMeetingApi sma = new ScheduleMeetingApi();
        ReminderMeeting reminderMeeting = new ReminderMeeting();
        reminderMeeting.setTitle("修改后的标题");
        // 开始时间，2个min之后
        reminderMeeting.setStartTime(System.currentTimeMillis() + (1000 * 60 * 2));
        // 结束时间，4个min之后，预约会议时长2minute
        reminderMeeting.setEndTime(System.currentTimeMillis() + (1000 * 60 * 4));
        reminderMeeting.setConferenceNumber(meetingRoomNumber);
        reminderMeeting.setAddress("地中海");
        reminderMeeting.setAutoInvite(1);
        return sma.updateMeeting(Config.ENTERPRISE_ID, Config.TOKEN, meetingId, reminderMeeting);
    }

    //删除会议
    public static Result deleteMeeting(String meetingId) throws IOException {
        ScheduleMeetingApi sma = new ScheduleMeetingApi();
        return sma.deleteMeeting(Config.ENTERPRISE_ID, Config.TOKEN, meetingId);
    }

    //按照结束时间获取会议
    public static Result<ReminderMeeting[]> getAllMeeting() throws IOException {
        ScheduleMeetingApi sma = new ScheduleMeetingApi();
        long endtime = System.currentTimeMillis();
        return sma.getAllMeeting(Config.ENTERPRISE_ID, Config.TOKEN, endtime);
    }
}
