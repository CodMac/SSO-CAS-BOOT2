package com.xylink.sdk.test;

import com.xylink.model.LV;
import com.xylink.model.LiveVideo;
import com.xylink.sdk.liveVideo.v2.LiveVideoApi;
import com.xylink.util.Result;
import org.junit.Test;

import java.io.IOException;

/**
 * Created by changxiangyang on 2017/10/10.
 * 请使用最新版本，see LiveVideoV3Test
 */
@Deprecated
public class LiveVideoTest {
    @Test
    public void newLive(){
        LiveVideoApi lva=new LiveVideoApi();
        String enterpriseid="fadfadfadfasdfadsfasdfa";
        String token = "fsdfasjdfkajfkadfajdfajf";
        String callNumber ="702301";
        LiveVideo liveVideo=new LiveVideo();
        liveVideo.setConfNo("915811043997");
        liveVideo.setTitle("123");
        liveVideo.setLocation("2374823");
        liveVideo.setAutoPublishRecording(false);
        liveVideo.setAutoRecording(false);
        liveVideo.setNemoNumber("702301");
        liveVideo.setEndTime(1509007888000l);
        liveVideo.setEndTime(1509009888000l);

        Result result=null;
        try {
            result = lva.newLiveVideo(enterpriseid, token,callNumber, liveVideo);
            if(result!=null){
                System.out.println(result.getErrorStatus());
                if(result.getErrorStatus()==200){
                    LV lv= (LV) result.getData();
                    System.out.println("lv="+lv.toString());
                }
            }
        }catch (IOException e){
            System.out.println("testEnd--"+e);
        }
    }
}
