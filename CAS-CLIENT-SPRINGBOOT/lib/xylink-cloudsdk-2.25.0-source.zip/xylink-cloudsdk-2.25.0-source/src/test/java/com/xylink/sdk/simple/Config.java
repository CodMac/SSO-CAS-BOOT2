package com.xylink.sdk.simple;

public class Config {
    public static String ENTERPRISE_ID = "12e53a6df2e91e6177e627c8e336a6888ff98104";// 3671473d0f3b155560b67c1b7a840fc266bb6aab
    public static String TOKEN = "a8208f6495ba1d468343cc63c13c5202837b5ba8614bdc699f46e91b4df09fd0"; //  72de07efe4d2ddcd568ce2d125ebbd185b4a28a3d12122db01b2b7d54ec666cb

}
