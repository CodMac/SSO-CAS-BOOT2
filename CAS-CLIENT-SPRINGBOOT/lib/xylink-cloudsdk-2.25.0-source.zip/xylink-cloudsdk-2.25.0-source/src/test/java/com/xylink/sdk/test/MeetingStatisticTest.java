package com.xylink.sdk.test;


import com.xylink.config.SDKConfigMgr;
import com.xylink.model.CallInviteRequest;
import com.xylink.model.CurrentMeeting;
import com.xylink.model.Device;
import com.xylink.model.DeviceInfo;
import com.xylink.model.DeviceMultiImageRequest;
import com.xylink.model.DeviceNotification;
import com.xylink.model.ListData;
import com.xylink.model.LiveContentLayoutType;
import com.xylink.model.LiveLayoutRequest;
import com.xylink.model.LivePeopleLayoutType;
import com.xylink.model.MeetingControlSubtitleRequest;
import com.xylink.model.MeetingRoom;
import com.xylink.model.MeetingStatus;
import com.xylink.model.MeetingSubtitle;
import com.xylink.model.MeetingSubtitleRequest;
import com.xylink.model.MlayoutResquest;
import com.xylink.model.SdkMeeting;
import com.xylink.model.SdkMeetingReq;
import com.xylink.model.ShareAuthTarget;
import com.xylink.model.statis.CurrentMeetingDetail;
import com.xylink.model.statis.SdkMeetingExportDto;
import com.xylink.model.statis.SdkParticipantExportDto;
import com.xylink.sdk.conferenceControl.ConferenceControlApi;
import com.xylink.sdk.conferenceControl.CreateMeetingApi;
import com.xylink.sdk.conferenceControl.MeetingStatisticApi;
import com.xylink.util.Result;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

/**
 * Created by xinzhixuan on 2018-12-20.
 */
public class MeetingStatisticTest {

    private static SdkMeeting sdkMeeting = null;
    private String enterpriseid= TestConfig.getInstance().getEnterpriseId();
    private String token = TestConfig.getInstance().getToken();
    @BeforeClass
    public static void setup() {
        SDKConfigMgr.setServerHost("https://172.18.160.42");
//        SDKConfigMgr.setServerHost("http://127.0.0.1:8081");
    }

    //  按会议时间导出会议详情
    @Test
    public void getByTime() {
        enterpriseid = "f3c422a7c36eac6c924ed2a50eb4f49f82b128de";
        token = "a727338bb95fb608dde30774a96ae712c4a71ab3a4d6b499282048852bfe5a43";

        MeetingStatisticApi meetingStatisticApi = new MeetingStatisticApi();
        Result<ListData<SdkMeetingExportDto>> result = null;
        try {
            result = meetingStatisticApi.getByTime(enterpriseid, token, 1544692961700L, 1544694761700L);
            System.out.println(result);
        }catch (IOException e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);
    }

    @Test
    public void getByParticipant(){
        enterpriseid = "f3c422a7c36eac6c924ed2a50eb4f49f82b128de";
        token = "a727338bb95fb608dde30774a96ae712c4a71ab3a4d6b499282048852bfe5a43";

        MeetingStatisticApi meetingStatisticApi = new MeetingStatisticApi();
        Result<ListData<SdkParticipantExportDto>> result = null;
        try {
            result = meetingStatisticApi.getByParticipant(enterpriseid, token, 1544692961700L, 1544694761700L);
            System.out.println(result);
        }catch (IOException e){
            fail(e.getMessage());
        }
        int errStatus = result.getErrorStatus();
        assertEquals(200, errStatus);
    }

}
