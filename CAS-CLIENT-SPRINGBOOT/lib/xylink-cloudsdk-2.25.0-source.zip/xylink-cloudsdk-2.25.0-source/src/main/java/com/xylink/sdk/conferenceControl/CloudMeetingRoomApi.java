package com.xylink.sdk.conferenceControl;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.*;
import com.xylink.util.HttpUtil;
import com.xylink.util.Result;
import com.xylink.util.SignatureSample;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import java.io.IOException;
import java.net.URLEncoder;

public class CloudMeetingRoomApi {
    private static SignatureSample signatureSample = new SignatureSample();
    private static final String prefixUrlMeetingInfo = "/api/rest/external/v1/conference/";



    /**
     * 根据类型查询企业的云会议室列表
     * @param enterpriseId
     * @param token
     * @return
     * @throws IOException
     */
    public Result<Pager<ConferenceMeetingRoom>> getCloudMeetingRooms(String enterpriseId, String token, String type, int page, int size) throws IOException {
        String surl = getMeetingInfoPrefixUrl() + "cloudConference?enterpriseId=" + enterpriseId + "&type=" + type + "&page=" + page + "&size=" + size;
        String signature = signatureSample.computeSignature("", "GET", token, surl);
        surl += "&signature=" + signature;
        Result<String> resp = HttpUtil.getResponse(surl, "GET", null, String.class);

        Result<Pager<ConferenceMeetingRoom>> result = new Result<Pager<ConferenceMeetingRoom>>();
        result.setSuccess(resp.isSuccess());
        result.setErrorStatus(resp.getErrorStatus());
        result.setErrorMsg(resp.getErrorMsg());

        if (result.isSuccess() && StringUtils.isNotBlank(resp.getData())) {
            ObjectMapper objectMapper = new ObjectMapper();
            Pager<ConferenceMeetingRoom> pager = objectMapper.readValue(resp.getData(), new TypeReference<Pager<ConferenceMeetingRoom>>() {});
            result.setData(pager);
        }

        return result;
    }

    private String getMeetingInfoPrefixUrl() {
        return SDKConfigMgr.getServerHost() + prefixUrlMeetingInfo;
    }
}
