package com.xylink.model.callback;

/**
 * Created by wenya on 16/4/9.
 */
public enum CallbackEvent {
    NemoUnbound,LiveStatus,NewCallPush,NewUserCall,ConferenceRosterInfo,
    // 录制结束
    RecordingStop
}
