package com.xylink.sdk.enterpriseNemo;
import com.xylink.config.SDKConfigMgr;
import com.xylink.model.NemoDto;
import com.xylink.model.PageableNemoDto;
import com.xylink.util.HttpUtil;
import com.xylink.util.Result;
import com.xylink.util.SignatureSample;
import org.codehaus.jackson.map.ObjectMapper;
import java.io.IOException;
import java.util.Arrays;

/**
 * created by maolizhi at 03/14/2017
 * get Enterprise Nemos
 */
public class EnterpriseNemoApi {
    private static SignatureSample signatureSample = new SignatureSample();
    private static final String prefixUrl = "/api/rest/external/v1/buffet/nemos";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * get enterprise all nemos(only nemo) acording to enterpriseId.
     * @param enterpriseId
     * @param token
     * @return
     * @throws IOException
     */
    public Result<NemoDto[]> getEnterpriseNemos(String enterpriseId, String token) throws IOException{

        String surl = SDKConfigMgr.getServerHost() + prefixUrl + "?enterprise_id=" + enterpriseId;
        String signature = signatureSample.computeSignature("","GET",token,surl);
        surl += "&signature=" + signature;
        return HttpUtil.getResponse(surl,"GET", null,NemoDto[].class);

    }

    /**
     * get enterprise pageable nemos(only nemo) acording to enterpriseId.
     * @param enterpriseId
     * @param token
     * @return
     * @throws IOException
     */
    public Result<PageableNemoDto> getPageableEnterpriseNemos(String enterpriseId, String token, int page, int pageSize) throws IOException{
        String surl = SDKConfigMgr.getServerHost() + prefixUrl + "/page?enterpriseId=" + enterpriseId + "&pageIndex=" + page + "&pageSize=" + pageSize;
        String signature = signatureSample.computeSignature("","GET",token,surl);
        surl += "&signature=" + signature;
        return HttpUtil.getResponse(surl,"GET", null, PageableNemoDto.class);

    }

    public static void main(String[] args) throws IOException {

//        Result<NemoDto[]> result = HttpUtil.getResponse("http://127.0.0.1:8081/api/rest/external/v1/buffet/nemos?enterpriseId=f5fa04ead49a888696d3bc5e5a64dd8f13f106db", "GET", null, NemoDto[].class);
//        System.out.println(Arrays.toString(result.getData()));
        Result<PageableNemoDto> pageableNemoDtoResult = HttpUtil.getResponse("http://127.0.0.1:8081/api/rest/external/v1/buffet/nemos/page?enterpriseId=f5fa04ead49a888696d3bc5e5a64dd8f13f106db", "GET", null, PageableNemoDto.class);
        System.out.println(pageableNemoDtoResult.getData());
    }
}
