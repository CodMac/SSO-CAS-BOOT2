package com.xylink.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: gzm
 * Date: 2018-12-04
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserValidateResponse {

    private String displayName;
    private String userDisplayName;
    private String cellPhone;
    private long userCreateTime;
    private String email;

    public UserValidateResponse() {
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getCellPhone() {
        return cellPhone;
    }

    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    public long getUserCreateTime() {
        return userCreateTime;
    }

    public void setUserCreateTime(long userCreateTime) {
        this.userCreateTime = userCreateTime;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserDisplayName() {
        return userDisplayName;
    }

    public void setUserDisplayName(String userDisplayName) {
        this.userDisplayName = userDisplayName;
    }

    @Override
    public String toString() {
        return "UserLoginResponse{" +
                "displayName='" + displayName + '\'' +
                ", cellPhone='" + cellPhone + '\'' +
                ", userCreateTime=" + userCreateTime +
                ", email='" + email + '\'' +
                '}';
    }
}
