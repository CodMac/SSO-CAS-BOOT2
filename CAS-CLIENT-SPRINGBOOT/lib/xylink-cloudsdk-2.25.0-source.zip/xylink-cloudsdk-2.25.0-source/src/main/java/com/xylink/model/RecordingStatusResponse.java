package com.xylink.model;

/**
 * Created by maolizhi on 4/7/17.
 */
public enum RecordingStatusResponse {
    NO_MEETING,SIG_SERVER_TIMEOUT, UNKNOWN_ERROR, OK,;
}
