package com.xylink.sdk.conferenceControl;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.ListData;
import com.xylink.model.Pager;
import com.xylink.model.statis.SdkMeetingExportDto;
import com.xylink.model.statis.SdkParticipantExportDto;
import com.xylink.util.HttpUtil;
import com.xylink.util.Result;
import com.xylink.util.SignatureSample;

import java.io.IOException;
import java.util.List;

/**
 * Created by xinzhixuan on 2018-12-20.
 */
public class MeetingStatisticApi {

    private static SignatureSample signatureSample = new SignatureSample();
    private static final String prefixUrl = "/api/rest/external/v1/meeting/statistic/";
    private static final String prefixUrl_1 = "/api/rest/external/v1/";

    /**
     *  按会议时间导出会议详情
     *
     * @param enterpriseId .
     * @param token .
     * @param timeBegin 开始时间
     * @param timeEnd 结束时间
     * @return .
     * @throws IOException .
     */
    public Result<ListData<SdkMeetingExportDto>> getByTime(String enterpriseId, String token, long timeBegin, long timeEnd) throws IOException {
        String surl = getPrefixUrl() + "enterprise?enterpriseId=" + enterpriseId + "&timeBegin=" + timeBegin + "&timeEnd=" + timeEnd;
        String signature = signatureSample.computeSignature("", "GET", token, surl);
        surl += "&signature=" + signature;
        return HttpUtil.getResponse(surl, "GET", "", ListData.class);
    }


    /**
     * 按参会者导出会议详情
     *
     * @param enterpriseId .
     * @param token .
     * @param timeBegin 开始时间
     * @param timeEnd 结束时间
     * @return .
     * @throws IOException .
     */
    public Result<ListData<SdkParticipantExportDto>> getByParticipant(String enterpriseId, String token, long timeBegin, long timeEnd) throws IOException {
        String surl = getPrefixUrl() + "participant?enterpriseId=" + enterpriseId + "&timeBegin=" + timeBegin + "&timeEnd=" + timeEnd;
        String signature = signatureSample.computeSignature("", "GET", token, surl);
        surl += "&signature=" + signature;
        return HttpUtil.getResponse(surl, "GET", "", ListData.class);

    }


    public Result<Pager> getByNemoNumber(String enterpriseId, String token, Long timeBegin, Long timeEnd,String nemoNumber) throws IOException {
        String surl = getPrefixUrl1() + "meeting/list?enterpriseId=" + enterpriseId + "&timeBegin=" + timeBegin + "&timeEnd=" + timeEnd+"&nemoNumber="+nemoNumber;
        String signature = signatureSample.computeSignature("", "GET", token, surl);
        surl += "&signature=" + signature;
        return HttpUtil.getResponse(surl, "GET", "", Pager.class);

    }


    public Result<Pager> getByMeetingId(String enterpriseId, String token, String meetingId) throws IOException {
        String surl = getPrefixUrl() + "participant/detail?enterpriseId=" + enterpriseId + "&meetingId=" + meetingId;
        String signature = signatureSample.computeSignature("", "GET", token, surl);
        surl += "&signature=" + signature;
        return HttpUtil.getResponse(surl, "GET", "", Pager.class);

    }

    private String getPrefixUrl() {
        return SDKConfigMgr.getServerHost() + prefixUrl;
    }
    private String getPrefixUrl1() {
        return SDKConfigMgr.getServerHost() + prefixUrl_1;
    }

}
