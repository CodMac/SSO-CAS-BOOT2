package com.xylink.config;

/**
 * Created by wenya on 17/9/11.
 */
public class SDKConfig {

    private String serverHost;

    public String getServerHost() {
        return serverHost;
    }

    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }
}
