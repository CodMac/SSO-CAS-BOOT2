package com.xylink.sdk.wechat;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.ExternalLoginRequest;
import com.xylink.model.SdkMiniProgramUserDto;
import com.xylink.model.UserValidateResponse;
import com.xylink.util.HttpUtil;
import com.xylink.util.Result;
import com.xylink.util.SignatureSample;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: gzm
 * Date: 2018-12-08
 */
public class MiniProgramApi {
    private static SignatureSample signatureSample = new SignatureSample();
    private static final String prefixUrl = "/api/rest/external/v1/";

    public Result<List<SdkMiniProgramUserDto>> batchUser(String enterpriseId, String token, String appId) throws IOException {
        String surl = getPrefixUrl() + "miniprogram/batch/users?enterpriseId="+enterpriseId +"&appId=" + appId ;
        String signature = signatureSample.computeSignature("","POST",token,surl);
        surl += "&signature=" + signature;
        try {
            Result<List<SdkMiniProgramUserDto>> SdkMiniProgramUserDtos = HttpUtil.getResponse(surl, "POST", null, List.class);
            if(SdkMiniProgramUserDtos.isSuccess()) {
                return SdkMiniProgramUserDtos;
            } else {
                throw new RuntimeException(SdkMiniProgramUserDtos.getErrorStatus() + "");
            }
        } catch (IOException e) {
            throw e;
        }
    }

    private String getPrefixUrl() {
        return SDKConfigMgr.getServerHost() + prefixUrl;
    }
}
