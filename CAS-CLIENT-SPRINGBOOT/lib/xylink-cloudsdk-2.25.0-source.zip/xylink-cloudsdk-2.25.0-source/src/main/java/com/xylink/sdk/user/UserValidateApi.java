package com.xylink.sdk.user;

import com.xylink.config.SDKConfigMgr;
import com.xylink.model.ExternalLoginRequest;
import com.xylink.model.UserValidateResponse;
import com.xylink.util.AES256Util;
import com.xylink.util.HttpUtil;
import com.xylink.util.Result;
import com.xylink.util.SignatureSample;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: gzm
 * Date: 2018-12-08
 */
public class UserValidateApi {
    private static SignatureSample signatureSample = new SignatureSample();
    private static final String prefixUrl = "/api/rest/external/v1/user/";

    public UserValidateResponse userValidate(String enterpriseId, String token, ExternalLoginRequest externalLoginRequest) throws IOException {
        String surl = getPrefixUrl() + "validate?enterpriseId="+enterpriseId ;
        if(externalLoginRequest == null || StringUtils.isBlank(externalLoginRequest.getPassword())
                || StringUtils.isBlank(externalLoginRequest.getUserPhone())) {
            return null;
        }
        String jsonEntity = new ObjectMapper().writeValueAsString(externalLoginRequest);
        String signature = signatureSample.computeSignature(jsonEntity,"POST",token,surl);
        surl += "&signature=" + signature;
        try {
            Result<UserValidateResponse> userValidateResponseResult = HttpUtil.getResponse(surl, "POST", jsonEntity, UserValidateResponse.class);
            if(userValidateResponseResult.isSuccess()) {
                return userValidateResponseResult.getData();
            } else {
                throw new RuntimeException(userValidateResponseResult.getErrorStatus() + "");
            }
        } catch (IOException e) {
            throw e;
        }
    }

    private String getPrefixUrl() {
        return SDKConfigMgr.getServerHost() + prefixUrl;
    }
}
