#!/bin/sh

gradle clean publish -Pprofile=prd --stacktrace --refresh-dependencies
